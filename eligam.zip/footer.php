<!-- FOOTER -->

<div class="row light footer">
  <div class="container">
    <div class="three columns">
      <div class="footer-column">
        <a class="strong">homeware</a>
        <a>kitchen</a>
        <a>living room</a>
        <a>bedroom</a>
        <a>bathroom</a>
        <a>furniture</a>
        <a>accessories</a>
      </div>
      <div class="footer-column">
        <a class="strong">music</a>
      </div>
    </div>
    <div class="three columns">
      <div class="footer-column">
        <a class="strong">clothing</a>
        <a>tops</a>
        <a>bottoms</a>
        <a>shoes</a>
        <a>outerwear</a>
        <a>accessories</a>
      </div>
      <div class="footer-column">
        <a class="strong">lifestyle</a>
        <a>sports</a>
        <a>headphones</a>
        <a>hi-fi</a>
      </div>
    </div>
    <div class="three columns">
      <div class="footer-column">
        <a class="strong">good reads</a>
        <a>design</a>
        <a>magazines</a>
        <a>novels</a>
        <a>food</a>
      </div>
      <div class="footer-column">
        <a class="strong">about us</a>
        <a class="strong">contact us</a>
        <a class="strong">how it works</a>
        <a class="strong">giving</a>
      </div>
    </div>
    <div class="three columns">
      <p>subscribe to our monthly newsletter for our key pickups:</p>
      <!-- Begin MailChimp Signup Form -->
<link href="//cdn-images.mailchimp.com/embedcode/horizontal-slim-10_7.css" rel="stylesheet" type="text/css">
<style type="text/css">
	#mc_embed_signup{background:#fff; clear:left; font:14px Helvetica,Arial,sans-serif; width:100%;}
	/* Add your own MailChimp form style overrides in your site stylesheet or in this style block.
	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
</style>
<div id="mc_embed_signup">
<form action="https://Eligam.us17.list-manage.com/subscribe/post?u=00fd71e48eebd26659aeced78&amp;id=23ad0f419c" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
    <div id="mc_embed_signup_scroll">

	<input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required>
    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
    <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_00fd71e48eebd26659aeced78_23ad0f419c" tabindex="-1" value=""></div>
    <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
    </div>
</form>
</div>

<!--End mc_embed_signup-->
    </div>
  </div>
</div>

<!-- END FOOTER -->

</body>
</html>
